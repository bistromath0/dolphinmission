/**
 * Classes for NPC/AI support, such as behavior trees.
 *
 * @author Kenneth Barnett, based on published work of Alex Champandard
 */
package tage.ai;