/**
 * <b>The TAGE core game engine classes.</b>
 *
 * @author Scott Gordon
 */
package tage;